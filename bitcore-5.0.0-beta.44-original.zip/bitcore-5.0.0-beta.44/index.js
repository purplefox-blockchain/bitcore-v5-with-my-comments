'use strict';

var bitcore = require('bitcore-lib');

module.exports = bitcore;
